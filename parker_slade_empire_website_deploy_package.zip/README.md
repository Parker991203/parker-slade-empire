# Parker Slade Empire website

A responsive static homepage for Parker Slade Empire and its five divisions.

## Deploy with Render

1. Create a GitHub repository named `parker-slade-empire`.
2. Upload the contents of this folder to the repository root (make sure `index.html` and `render.yaml` are at the top level).
3. In Render, choose **New + → Blueprint** and connect the repository.
4. Render should detect `render.yaml` and create the static site.
5. After deployment, open the `onrender.com` URL shown by Render.

## Before launch

- Replace the placeholder contact email `hello@parkerslade.com` with an email address you control.
- Connect a custom domain when you own it.
- Add individual division pages and real contact/social links as they become available.
